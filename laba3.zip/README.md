# ics-fp-2016
Functional programming learning in ICS 2016.
